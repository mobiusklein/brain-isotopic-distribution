The BRAIN program requires as input, a text file in which each row represents a molecule, for example:
C50H71O13N12S0 10
C253H377N65O75S6 20
…

The number of isotope variants that are calculated can be specified by the value after the molecular formula. If this number is set to ‘0’ then the default value from equation (2) is used. The BRAIN function can be simply called by 
>useBRAIN -i input_file_name -o output_file_name

A text file is generated as output that contains the following information for each elemental composition:
C50H71N12O13
1047.526245
1048.19406941554
1048.19407848709
0.999997560240673
1047.526245    0.525900022021616
1048.52921174009    0.32571028180423
1049.53196381415    0.113124671826019
1050.53461661812    0.0284242902684196
1051.53720694336    0.00570889335071694
1052.53975402631    0.00096608176824854
…

The first row repeats the molecular formula. The second and third row indicate the theoretical monoisotopic and average mass, respectively. The fourth row gives the empirical average mass calculated as a weighted sum of the returned masses and probabilities. If the isotope distribution is correctly covered  this value should be close to the theoretical average mass. Another metric that quantify the coverage of the isotope distribution is provided in the fifth row as the sum of the returned probabilities. For the covered distribution, this value should be close to one.

Other command line options can be viewed by typing:
>useBRAIN.exe -h
